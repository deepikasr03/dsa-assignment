class Stack:
#create an empty stack
	def __init__(self):		
	    self._data = []

	def push(self,x):
              """ Add element e to the top of the Stack """
		self._data.append(x)

	def pop(self):
                """ Remove and return the element from the top of the stack"""

		if(self.is_empty()):
			print("stack is empty")
		else:
		    return self._data.pop()

	def is_empty(self):
		return len(self._data) == 0

if __name__ == '__main__':
         """ main function """
	s = Stack()
	List = [110,20,30,40,50]
	length=len(List)
	print(length)
	for i in range(len(List)):
		s.push(List[i])
	List = []
	for i in range(length):
		List.append(s.pop())
	print(List)
		
